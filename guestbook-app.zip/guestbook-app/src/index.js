import React from 'react';
// import ReactDOM from 'react-dom/client';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

// const root = ReactDOM.createRoot(document.getElementById('root'));
//root.render(
//  <React.StrictMode>
//    <App />
//  </React.StrictMode>
//);

class GuestBookApp extends HTMLElement {
  connectedCallback() {

    createRoot(this).render(
      <React.StrictMode>
        <App/>
      </React.StrictMode>
    );
  }
}

const ELEMENT_ID = 'guestbook-app';

if (!customElements.get(ELEMENT_ID)) {
  customElements.define(ELEMENT_ID, GuestBookApp);
}

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
