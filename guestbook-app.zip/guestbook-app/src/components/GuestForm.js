import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button, TextField, Paper, Grid, Typography } from '@mui/material';

const GuestForm = ({ addGuest, selectedGuest, updateGuest }) => {
    const [name, setName] = useState('');
    const [contact, setContact] = useState('');
    const [email, setEmail] = useState('');
    const [purpose, setPurpose] = useState('');

    useEffect(() => {
        if (selectedGuest) {
            setName(selectedGuest.name);
            setContact(selectedGuest.contact);
            setEmail(selectedGuest.email);
            setPurpose(selectedGuest.purpose);
        }
    }, [selectedGuest]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const time = new Date().toLocaleString();
        const newGuest = { name, contact, email, purpose, time };

        try {
            if (selectedGuest) {
                await axios.put(
                    `http://localhost:8080/o/c/guestbookentries/${selectedGuest.id}`,
                    newGuest,
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Basic ' + btoa('rahul.holalkere@liferay.com:liferay')
                        }
                    }
                );
                updateGuest(selectedGuest.id, newGuest);
            } else {
                const response = await axios.post(
                    'http://localhost:8080/o/c/guestbookentries/',
                    newGuest,
                    {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': 'Basic ' + btoa('rahul.holalkere@liferay.com:liferay')
                        }
                    }
                );
                addGuest(response.data);
            }
            setName('');
            setContact('');
            setEmail('');
            setPurpose('');
        } catch (error) {
            console.error('There was an error saving the guest entry!', error);
        }
    };

    return (
        <Paper elevation={3} style={{ padding: 20, marginBottom: 20 }}>
            <Typography variant="h6" gutterBottom>
                {selectedGuest ? 'Edit Guest Information' : 'Add Guest Information'}
            </Typography>
            <form onSubmit={handleSubmit}>
                <Grid container spacing={3}>
                    <Grid item xs={12}>
                        <TextField
                            label="Name"
                            fullWidth
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            label="Contact"
                            fullWidth
                            value={contact}
                            onChange={(e) => setContact(e.target.value)}
                            required
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            label="Email"
                            fullWidth
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField
                            label="Purpose of Visit"
                            fullWidth
                            value={purpose}
                            onChange={(e) => setPurpose(e.target.value)}
                            required
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <Button type="submit" variant="contained" color="primary">
                            {selectedGuest ? 'Update Guest' : 'Add Guest'}
                        </Button>
                    </Grid>
                </Grid>
            </form>
        </Paper>
    );
};

export default GuestForm;