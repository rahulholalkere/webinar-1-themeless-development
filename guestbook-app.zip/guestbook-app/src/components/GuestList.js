import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import './GuestList.css';

const GuestList = ({ setSelectedGuest, removeGuest }) => {
    const [guests, setGuests] = useState([]);

    useEffect(() => {
        const fetchGuests = async () => {
            try {
                const response = await axios.get(
                    'http://localhost:8080/o/c/guestbookentries/',
                    {
                        headers: {
                            'Authorization': 'Basic ' + btoa('rahul.holalkere@liferay.com:liferay')
                        }
                    }
                );
                setGuests(response.data.items);
            } catch (error) {
                console.error('There was an error fetching the guest entries!', error);
            }
        };

        fetchGuests();
    }, []);

    const handleDelete = async (id) => {
        try {
            await axios.delete(
                `http://localhost:8080/o/c/guestbookentries/${id}`,
                {
                    headers: {
                        'Authorization': 'Basic ' + btoa('rahul.holalkere@liferay.com:liferay')
                    }
                }
            );
            removeGuest(id);
        } catch (error) {
            console.error('There was an error deleting the guest entry!', error);
        }
    };

    return (
        <div>
            <Typography variant="h6" gutterBottom>
                All Guest Information
            </Typography>
            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Name</TableCell>
                            <TableCell>Contact</TableCell>
                            <TableCell>Email</TableCell>
                            <TableCell>Purpose</TableCell>
                            <TableCell>Time</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {guests.map((guest) => (
                            <TableRow key={guest.id}>
                                <TableCell>{guest.name}</TableCell>
                                <TableCell>{guest.contact}</TableCell>
                                <TableCell>{guest.email}</TableCell>
                                <TableCell>{guest.purpose}</TableCell>
                                <TableCell>{guest.time}</TableCell>
                                <TableCell>
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        onClick={() => setSelectedGuest(guest)}
                                        style={{ marginRight: '10px' }}
                                    >
                                        Edit
                                    </Button>
                                    <Button
                                        variant="contained"
                                        color="secondary"
                                        onClick={() => handleDelete(guest.id)}
                                    >
                                        Delete
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
};

export default GuestList;