import React, { useState } from 'react';
import GuestForm from './components/GuestForm';
import GuestList from './components/GuestList';
import './App.css';

const App = () => {
    const [selectedGuest, setSelectedGuest] = useState(null);
    const [guests, setGuests] = useState([]);

    const addGuest = (guest) => {
        setGuests([...guests, guest]);
    };

    const updateGuest = (id, updatedGuest) => {
        setGuests(guests.map(guest => guest.id === id ? updatedGuest : guest));
        setSelectedGuest(null);
    };

    const removeGuest = (id) => {
        setGuests(guests.filter(guest => guest.id !== id));
    };

    return (
        <div className="App">
            <h1>Office Guestbook</h1>
            <GuestForm
                addGuest={addGuest}
                selectedGuest={selectedGuest}
                updateGuest={updateGuest}
            />
            <GuestList
                setSelectedGuest={setSelectedGuest}
                removeGuest={removeGuest}
            />
        </div>
    );
};

export default App;